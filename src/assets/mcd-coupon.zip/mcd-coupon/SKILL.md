---
name: mcd-coupon
description: 麦当劳优惠券自动领取工具。当用户要获取麦当劳优惠券、领取麦当劳优惠券、查看麦当劳优惠券、或提到"麦当劳"和"优惠券"相关内容时使用此skill。支持自动获取Token、查看可用优惠券、一键领取优惠券、查看已领取的优惠券。
---

# 麦当劳优惠券工具

自动获取麦当劳MCP平台Token并领取优惠券。

## 工作流程

### 步骤1：收集用户手机号

使用 `AskUserQuestion` 工具询问用户手机号：

```
问题：请输入您的麦当劳账号手机号（用于接收验证码）
```

验证手机号格式：必须是11位数字，以1开头，第二位是3-9。

### 步骤2：运行脚本获取Token

收到手机号后，运行脚本（脚本会在同一个浏览器会话中完成发送验证码、等待验证码、登录、获取Token的全部流程）：

```bash
cd <skill-directory>/scripts && npx --yes --package=puppeteer -- node index.js --phone <用户手机号>
```

**重要**：此命令必须在后台运行（使用 `run_in_background: true`），因为脚本会保持浏览器运行并轮询等待验证码文件。

脚本会：
1. 启动无头浏览器访问 https://open.mcd.cn/mcp/login
2. 自动输入手机号、勾选协议、点击获取验证码
3. **保持浏览器运行**，轮询等待 `<skill-directory>/scripts/verification_code.txt` 文件
4. 读取到验证码后，在同一浏览器会话中完成登录
5. 获取Token并保存到 `token.txt` 和 `token.json` 文件

### 步骤2.5：等待信号并收集验证码

1. 通过 Read 工具或 Bash `tail` 命令读取后台任务输出，等待出现 `SIGNAL: WAITING_FOR_CODE` 信号
2. 看到信号后，使用 `AskUserQuestion` 工具询问用户收到的6位数字验证码
3. 将验证码写入文件：
   ```bash
   echo "<验证码>" > <skill-directory>/scripts/verification_code.txt
   ```
4. 脚本会自动检测到文件，读取验证码并继续完成登录流程
5. 通过 Read 工具或 Bash `tail` 命令读取后台任务输出，等待脚本执行完成（出现 `Token已保存` 或错误信息）

### 步骤3：配置并启动MCP服务器

获取到Token后，配置到mcd-coupon项目（Token已自动添加 `Bearer ` 前缀）：

1. 读取脚本保存的 `token.txt` 文件内容
2. 将Token写入配置文件：
   ```bash
   # 读取token并写入配置
   TOKEN=$(cat <skill-directory>/scripts/token.txt)
   echo "{\"token\":\"$TOKEN\"}" > ~/Library/Application\ Support/mcd-coupon-tui-rust/config.json
   ```
3. 启动MCP服务器模式（后台运行）：
   ```bash
   /Users/shijianzhong/sking/mcd-coupon/target/release/mcd-coupon-tui-rust mcpserver
   ```

MCP服务器默认监听 `http://localhost:8080`

### 步骤4：调用MCP工具

MCP服务器提供以下工具：

| 工具名称 | 描述 |
|---------|------|
| `available-coupons` | 获取所有可用的麦当劳优惠券 |
| `auto-bind-coupons` | 一键领取所有可用的麦当劳优惠券 |
| `my-coupons` | 查看已领取的麦当劳优惠券 |
| `now-time-info` | 获取当前时间信息 |

调用示例（JSON-RPC 2.0）：

```bash
# 获取可用优惠券
curl -X POST http://localhost:8080 \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"available-coupons","arguments":{}},"id":1}'

# 一键领取所有优惠券
curl -X POST http://localhost:8080 \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"auto-bind-coupons","arguments":{}},"id":1}'

# 查看已领取的优惠券
curl -X POST http://localhost:8080 \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"my-coupons","arguments":{}},"id":1}'
```

## 快速使用

如果Token已配置且MCP服务器已启动，可直接调用工具获取优惠券。

常用操作：
- **查看有什么优惠券**：调用 `available-coupons`
- **一键领取所有优惠券**：调用 `auto-bind-coupons`
- **查看我领取的优惠券**：调用 `my-coupons`

## 脚本说明

### scripts/index.js

使用Puppeteer自动化获取麦当劳MCP平台Token：
- 无头模式运行，用户无感
- 支持命令行参数：
  - `--phone <手机号>`: 指定手机号
  - `--code-file <文件路径>`: 指定验证码文件路径（默认为 scripts/verification_code.txt）
- 发送验证码后通过文件轮询等待验证码，浏览器保持运行不关闭
- 自动从API响应中捕获Token
- Token保存时自动添加 `Bearer ` 前缀，可直接用于MCP服务器配置
- Token保存到token.txt和token.json

### 命令行用法

```bash
# 完整流程：输入手机号 → 发送验证码 → 轮询等待验证码文件 → 登录 → 获取Token
node index.js --phone 13812345678
```

## 配置文件位置

Token配置文件（mcd-coupon项目）：
- macOS: `~/Library/Application Support/mcd-coupon-tui-rust/config.json`
- Linux: `~/.config/mcd-coupon-tui-rust/config.json`
- Windows: `%APPDATA%\mcd-coupon-tui-rust\config.json`
