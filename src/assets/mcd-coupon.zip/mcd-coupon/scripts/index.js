const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// 解析命令行参数
function parseArgs() {
  const args = process.argv.slice(2);
  const params = {
    phone: null,
    codeFile: null
  };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--phone' && args[i + 1]) {
      params.phone = args[i + 1];
      i++;
    } else if (args[i] === '--code-file' && args[i + 1]) {
      params.codeFile = args[i + 1];
      i++;
    }
  }

  return params;
}

// 通过文件轮询等待验证码（用于非交互式环境如 Claude Code）
function waitForCodeFile(codeFilePath, timeoutMs = 300000) {
  return new Promise((resolve, reject) => {
    const pollInterval = 1000; // 每秒检查一次
    let elapsed = 0;

    const timer = setInterval(() => {
      try {
        if (fs.existsSync(codeFilePath)) {
          const code = fs.readFileSync(codeFilePath, 'utf8').trim();
          if (/^\d{6}$/.test(code)) {
            clearInterval(timer);
            // 读取后删除文件
            fs.unlinkSync(codeFilePath);
            resolve(code);
          }
        }
      } catch (e) {
        // 忽略读取错误，继续轮询
      }

      elapsed += pollInterval;
      if (elapsed >= timeoutMs) {
        clearInterval(timer);
        reject(new Error('等待验证码超时（5分钟）'));
      }
    }, pollInterval);
  });
}

async function loginToMcd(options = {}) {
  const cmdArgs = parseArgs();
  // 合并命令行参数和函数参数，命令行参数优先
  const params = {
    phone: cmdArgs.phone || options.phone || null,
    codeFile: cmdArgs.codeFile || options.codeFile || null
  };

  console.log('正在打开麦当劳MCP平台登录页面...');

  // 使用无头模式，完全看不到浏览器
  const isHeadless = 'new';
  console.log('正在启动无头模式浏览器（完全无感）...');

  // 启动浏览器
  const browser = await puppeteer.launch({
    headless: isHeadless, // 使用无头模式
    defaultViewport: {
      width: 1920,
      height: 1080
    },
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--disable-features=IsolateOrigins,site-per-process',
      '--disable-notifications',
      '--disable-popup-blocking'
    ]
  });
  
  const page = await browser.newPage();

  // 拦截网络请求，捕获Token
  let capturedToken = null;
  page.on('response', async (response) => {
    try {
      const url = response.url();
      
      // 专门捕获返回Token的API端点
      if (url.includes('bff/member/user/api-key/query')) {
        try {
          const contentType = response.headers()['content-type'] || '';
          if (contentType.includes('application/json')) {
            const data = await response.json();
            
            // 检查响应结构并提取token
            if (data.success === true && data.data && data.data.key) {
              capturedToken = data.data.key;
              console.log('✓ 从API响应中捕获到完整Token:', capturedToken);
              console.log('✓ Token过期时间:', data.data.expireDate || '永不过期');
            }
          }
        } catch (e) {
          console.log('解析Token响应失败:', e.message);
        }
      }
      
      // 同时也检查其他可能的API响应
      else if (url.includes('api') || url.includes('token') || url.includes('auth')) {
        try {
          const contentType = response.headers()['content-type'] || '';
          if (contentType.includes('application/json')) {
            const data = await response.json();
            
            // 搜索响应中的token
            if (data.success === true && data.data && data.data.key) {
              capturedToken = data.data.key;
              console.log('✓ 从其他API响应中捕获到Token:', capturedToken);
            }
          }
        } catch (e) {
          // 忽略非JSON响应
        }
      }
    } catch (error) {
      // 忽略错误
    }
  });

  // 使用 CDP (Chrome DevTools Protocol) 授予剪贴板读取权限
  const client = await page.target().createCDPSession();

  // 授予剪贴板权限，确保可以在无头模式下访问剪贴板
  await client.send('Browser.grantPermissions', {
    permissions: ['clipboardReadWrite', 'clipboardSanitizedWrite'],
  });

  // 也可以使用页面级别的权限设置
  const context = browser.defaultBrowserContext();
  await context.overridePermissions('https://open.mcd.cn', [
    'clipboard-read',
    'clipboard-write'
  ]);

  console.log('✓ 已自动授予剪贴板读取权限（无头模式）');

  try {
    // 导航到登录页面
    await page.goto('https://open.mcd.cn/mcp/login', {
      waitUntil: 'networkidle2',
      timeout: 60000
    });
    
    console.log('页面加载完成，开始登录流程...');

    // 获取手机号：必须通过命令行参数传入
    let phoneNumber = params.phone;
    if (!phoneNumber) {
      throw new Error('请通过 --phone 参数传入手机号');
    }

    // 验证手机号格式
    if (!/^1[3-9]\d{9}$/.test(phoneNumber)) {
      throw new Error('无效的手机号码格式');
    }

    console.log(`手机号: ${phoneNumber}`);
    
    // 等待手机号输入框出现并输入手机号
    console.log('正在输入手机号...');

    // 使用精确的ID选择器等待手机号输入框
    console.log('等待手机号输入框出现...');
    await page.waitForSelector('#basic_phone', {
      timeout: 30000
    }).catch(error => {
      console.error('等待手机号输入框超时:', error);
      throw error;
    });
    
    console.log('正在输入手机号...');
    await page.type('#basic_phone', phoneNumber, { delay: 100 });
    console.log('✓ 手机号输入完成');
    
    // 勾选同意协议（在获取验证码之前必须勾选）
    console.log('正在勾选同意协议...');
    await page.waitForSelector('#basic_agreement', {
      timeout: 30000
    }).catch(error => {
      console.error('等待同意协议复选框超时:', error);
      throw error;
    });
    
    // 检查是否已勾选
    const isChecked = await page.evaluate(el => el.checked, await page.$('#basic_agreement'));
    if (!isChecked) {
      await page.click('#basic_agreement');
      console.log('✓ 同意协议已勾选');
    } else {
      console.log('✓ 同意协议已默认勾选');
    }
    
    // 自动点击获取验证码按钮
    console.log('正在点击获取验证码按钮...');
    
    // 使用精确的选择器等待获取验证码按钮
    await page.waitForSelector('.pfe-input-suffix button', {
      timeout: 30000
    }).catch(error => {
      console.error('等待获取验证码按钮超时:', error);
      throw error;
    });
    
    console.log('正在点击获取验证码按钮...');
    await page.click('.pfe-input-suffix button');
    console.log('✓ 获取验证码按钮点击完成');
    console.log('✓ 验证码已发送，请查收短信');

    // 通过文件轮询等待验证码（浏览器保持运行）
    const codeFilePath = params.codeFile || path.join(__dirname, 'verification_code.txt');
    // 写入信号文件，通知外部验证码已发送
    const signalFilePath = path.join(__dirname, 'waiting_for_code.txt');
    fs.writeFileSync(signalFilePath, 'waiting', 'utf8');
    console.log('SIGNAL: WAITING_FOR_CODE');
    console.log(`等待验证码写入文件: ${codeFilePath}`);

    let verificationCode = await waitForCodeFile(codeFilePath);
    // 删除信号文件
    try { fs.unlinkSync(signalFilePath); } catch (e) {}
    console.log('已收到验证码');

    console.log(`验证码: ${verificationCode}`);
    
    // 输入验证码
    console.log('正在输入验证码...');
    
    // 使用精确的ID选择器等待验证码输入框
    await page.waitForSelector('#basic_smsCode', {
      timeout: 30000
    }).catch(error => {
      console.error('等待验证码输入框超时:', error);
      throw error;
    });
    
    console.log('正在输入验证码...');
    await page.type('#basic_smsCode', verificationCode, { delay: 100 });
    console.log('✓ 验证码输入完成');
    
    // 点击登录按钮
    console.log('正在点击登录按钮...');
    
    // 使用精确的类选择器等待登录按钮
    await page.waitForSelector('.login-btn', {
      timeout: 30000
    }).catch(error => {
      console.error('等待登录按钮超时:', error);
      throw error;
    });
    
    console.log('正在点击登录按钮...');
    await page.click('.login-btn');
    console.log('✓ 登录按钮点击完成');
    
    // 等待登录成功
    console.log('正在验证登录状态...');
    await page.waitForNavigation({
      waitUntil: 'networkidle2',
      timeout: 60000
    }).catch(() => {
      // 忽略导航超时错误，因为有时登录后可能不会跳转
      console.log('登录操作已完成，正在检查页面状态...');
    });
    
    // 检查登录状态，确保没有跳回登录页面
    let loginAttempts = 0;
    const maxLoginAttempts = 3;
    
    while (loginAttempts < maxLoginAttempts) {
      // 检查当前页面URL
      const currentUrl = page.url();
      console.log(`当前页面: ${currentUrl}`);
      
      // 检查是否跳回了登录页面
      if (currentUrl.includes('/login')) {
        loginAttempts++;
        console.log(`登录失败，跳回了登录页面 (尝试 ${loginAttempts}/${maxLoginAttempts})`);
        
        if (loginAttempts >= maxLoginAttempts) {
          throw new Error('登录失败，多次尝试后仍跳回登录页面');
        }
        
        // 等待一段时间后重新尝试登录
        console.log('等待3秒后重新尝试登录...');
        await new Promise(resolve => setTimeout(resolve, 3000));

        // 重新输入验证码
        let newVerificationCode;

        console.log('验证码错误，需要重新输入验证码');
        const retryCodeFilePath = params.codeFile || path.join(__dirname, 'verification_code.txt');
        const retrySignalFilePath = path.join(__dirname, 'waiting_for_code.txt');
        fs.writeFileSync(retrySignalFilePath, 'waiting_retry', 'utf8');
        console.log('SIGNAL: WAITING_FOR_CODE');

        newVerificationCode = await waitForCodeFile(retryCodeFilePath);
        try { fs.unlinkSync(retrySignalFilePath); } catch (e) {}
        console.log(`您输入的新验证码: ${newVerificationCode}`);
        
        // 清除并重新输入验证码
        await page.click('#basic_smsCode');
        await page.keyboard.down('Control');
        await page.keyboard.press('A');
        await page.keyboard.up('Control');
        await page.keyboard.press('Backspace');
        await page.type('#basic_smsCode', newVerificationCode, { delay: 100 });
        
        // 重新点击登录按钮
        await page.click('.login-btn');
        console.log('重新点击登录按钮完成');
        
        // 等待导航
        await page.waitForNavigation({
          waitUntil: 'networkidle2',
          timeout: 60000
        }).catch(() => {
          console.log('登录操作已完成，正在检查页面状态...');
        });
      } else {
        // 登录成功，跳出循环
        console.log('✓ 登录成功！');
        break;
      }
    }
    
    // 登录后会自动跳转到 https://open.mcd.cn/mcp，无需手动跳转
    console.log('正在等待页面加载完成...');

    // 等待页面稳定
    console.log('等待页面稳定...');
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // 点击控制台按钮
    console.log('正在点击控制台按钮...');
    
    // 等待控制台按钮出现
    await page.waitForSelector('.pfe-btn.pfe-btn-primary.btn', {
      timeout: 60000
    }).catch(error => {
      console.error('等待控制台按钮超时:', error);
      throw error;
    });
    
    // 点击控制台按钮
    await page.click('.pfe-btn.pfe-btn-primary.btn');
    console.log('✓ 控制台按钮点击完成');

    // 等待弹窗出现
    console.log('等待Token弹窗出现...');
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // 从多个来源获取Token，不依赖剪贴板
    console.log('正在从多个来源获取Token...');
    
    let finalToken = null;

    try {
      // 方法1：检查是否从网络响应中捕获到Token（最可靠）
      if (capturedToken && capturedToken.length >= 30) {
        finalToken = capturedToken;
        console.log('✓ 从网络响应中获取完整Token:', finalToken);
      } else {
        console.log('方法1：网络响应中没有捕获到Token');
      }

      // 方法2：从页面HTML中直接提取Token
      if (!finalToken) {
        console.log('方法2：从页面HTML中提取Token...');
        
        const htmlToken = await page.evaluate(() => {
          // 获取整个页面的HTML
          const html = document.documentElement.outerHTML;
          
          // 匹配30-40个字符的字母数字组合
          const tokenPattern = /[A-Za-z0-9]{30,40}/g;
          const matches = html.match(tokenPattern);
          
          if (matches) {
            // 过滤掉常见的HTML类名和ID
            const excludePatterns = [
              /wrapper/i,
              /container/i,
              /checkbox/i,
              /input/i,
              /button/i,
              /modal/i,
              /dropdown/i,
              /cascader/i,
              /form/i,
              /item/i,
              /icon/i,
              /prefix/i,
              /suffix/i
            ];
            
            for (const match of matches) {
              let shouldExclude = false;
              for (const excludePattern of excludePatterns) {
                if (excludePattern.test(match)) {
                  shouldExclude = true;
                  break;
                }
              }
              
              if (!shouldExclude) {
                return match;
              }
            }
          }
          
          return null;
        });

        if (htmlToken && htmlToken.length >= 30) {
          finalToken = htmlToken;
          console.log('✓ 从页面HTML成功获取完整Token:', finalToken);
        } else {
          console.log('方法2：未从页面HTML中找到Token');
        }
      }

      // 方法3：从localStorage/sessionStorage中提取Token
      if (!finalToken) {
        console.log('方法3：尝试从浏览器存储中提取Token...');
        
        const storageToken = await page.evaluate(() => {
          // 检查localStorage
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            const value = localStorage.getItem(key);
            if (value && value.length > 30) {
              const match = value.match(/[A-Za-z0-9]{30,}/);
              if (match && match[0].length > 30) {
                return match[0];
              }
            }
          }

          // 检查sessionStorage
          for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            const value = sessionStorage.getItem(key);
            if (value && value.length > 30) {
              const match = value.match(/[A-Za-z0-9]{30,}/);
              if (match && match[0].length > 30) {
                return match[0];
              }
            }
          }

          return null;
        });

        if (storageToken && storageToken.length > 30) {
          finalToken = storageToken;
          console.log('✓ 从浏览器存储成功获取完整Token:', finalToken);
        } else {
          console.log('方法3：未从浏览器存储中找到Token');
        }
      }

      // 方法4：从Cookies中提取Token
      if (!finalToken) {
        console.log('方法4：尝试从Cookies中提取Token...');
        
        const cookies = await page.cookies();
        for (const cookie of cookies) {
          if (cookie.value && cookie.value.length > 30) {
            const match = cookie.value.match(/[A-Za-z0-9]{30,}/);
            if (match && match[0].length > 30) {
              finalToken = match[0];
              console.log('✓ 从Cookies成功获取完整Token:', finalToken);
              break;
            }
          }
        }

        if (!finalToken) {
          console.log('方法4：未从Cookies中找到Token');
        }
      }

      // 方法5：从JavaScript变量和window对象中提取Token
      if (!finalToken) {
        console.log('方法5：尝试从JavaScript变量中提取Token...');
        
        const jsToken = await page.evaluate(() => {
          // 检查window对象中的所有属性
          const tokenKeys = Object.keys(window);
          for (const key of tokenKeys) {
            try {
              const value = window[key];
              if (value && typeof value === 'string' && value.length > 30) {
                const match = value.match(/[A-Za-z0-9]{30,}/);
                if (match && match[0].length > 30) {
                  return match[0];
                }
              }
            } catch (e) {
              // 忽略无法访问的属性
            }
          }
          
          return null;
        });

        if (jsToken && jsToken.length > 30) {
          finalToken = jsToken;
          console.log('✓ 从JavaScript变量成功获取完整Token:', finalToken);
        } else {
          console.log('方法5：未从JavaScript变量中找到Token');
        }
      }

      // 方法6：从DOM元素中提取Token
      if (!finalToken) {
        console.log('方法6：从DOM元素中提取Token...');
        
        const domToken = await page.evaluate(() => {
          // 查找所有可能包含Token的元素
          const possibleSelectors = [
            '.key-value',
            '.token-value',
            '[class*="token"]',
            '[class*="key"]',
            'code',
            'pre',
            '.aurum-input',
            '.pfe-input',
            '.pfe-modal-body'
          ];
          
          for (const selector of possibleSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
              const text = element.textContent || element.value || element.innerText;
              if (text && text.length >= 30 && text.length <= 40) {
                const tokenMatch = text.match(/[A-Za-z0-9]{30,}/);
                if (tokenMatch) {
                  return tokenMatch[0];
                }
              }
            }
          }
          
          return null;
        });

        if (domToken && domToken.length >= 30) {
          finalToken = domToken;
          console.log('✓ 从DOM元素成功获取完整Token:', finalToken);
        } else {
          console.log('方法6：未从DOM元素中找到Token');
        }
      }

      if (finalToken) {
        console.log('\n========================================');
        console.log('🎉 Token获取成功！');
        console.log('完整Token:', finalToken);
        console.log('Token长度:', finalToken.length);
        console.log('========================================\n');
      } else {
        console.log('⚠️ 未能通过任何方法获取到Token');
      }

    } catch (error) {
      console.log('获取Token过程中出错:', error.message);
    }
    
    // 如果成功获取到token，保存到文件
    if (finalToken) {
      try {
        // 添加 Bearer 前缀（MCP Server 需要）
        const bearerToken = finalToken.startsWith('Bearer ') ? finalToken : `Bearer ${finalToken}`;

        const tokenData = {
          token: bearerToken,
          timestamp: new Date().toISOString(),
          phone: phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') // 脱敏处理
        };

        fs.writeFileSync('token.json', JSON.stringify(tokenData, null, 2), 'utf8');
        console.log('✓ Token已保存到 token.json 文件');

        // 同时保存纯文本格式（带 Bearer 前缀）
        fs.writeFileSync('token.txt', bearerToken, 'utf8');
        console.log('✓ Token已保存到 token.txt 文件');
      } catch (error) {
        console.log('保存Token文件失败:', error.message);
      }
    }

    console.log('\n✓ 登录流程全部完成！');
    console.log('现在可以开始使用Token访问麦当劳API了');
    
  } catch (error) {
    console.error('❌ 登录过程中出错:', error.message);
    console.error('错误详情:', error);
  } finally {
    // 关闭浏览器
    console.log('\n正在关闭浏览器...');
    await browser.close();
    console.log('✓ 浏览器已关闭');
  }
}

// 启动登录流程
if (require.main === module) {
  loginToMcd().catch(console.error);
}

module.exports = { loginToMcd };
