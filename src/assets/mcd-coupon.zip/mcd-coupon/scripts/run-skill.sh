#!/bin/bash

# 麦当劳Token获取脚本

echo "开始获取麦当劳MCP平台Token..."

# 检查Node.js是否安装
if ! command -v node &> /dev/null; then
    echo "错误: 未安装Node.js，请先安装Node.js 18或更高版本"
    exit 1
fi

# 使用npx创建临时依赖并运行脚本
echo "正在运行Token获取脚本..."
npx --yes --package=puppeteer --package=inquirer -- node index.js

# 检查是否成功获取Token
if [ -f "token.txt" ]; then
    TOKEN=$(cat token.txt)
    echo "\n🎉 Token获取成功！"
    echo "完整Token: $TOKEN"
    echo "Token已保存到 token.txt 文件"
    exit 0
else
    echo "\n❌ Token获取失败，请检查网络连接或重试"
    exit 1
fi
