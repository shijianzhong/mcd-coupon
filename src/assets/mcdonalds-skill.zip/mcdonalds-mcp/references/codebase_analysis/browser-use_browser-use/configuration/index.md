# Configuration Patterns

*Detected configuration files (C3.4)*

**Total Config Files**: 28

## Configuration Files

### `.pre-commit-config.yaml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `Dockerfile`

- **Type**: dockerfile
- **Purpose**: docker_configuration
- **Settings**: 7

### `pyproject.toml`

- **Type**: toml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `Dockerfile.fast`

- **Type**: dockerfile
- **Purpose**: docker_configuration
- **Settings**: 3

### `.env.example`

- **Type**: env
- **Purpose**: ci_cd_configuration
- **Settings**: 7

### `docker/base-images/chromium/Dockerfile`

- **Type**: dockerfile
- **Purpose**: docker_configuration
- **Settings**: 1

### `docker/base-images/system/Dockerfile`

- **Type**: dockerfile
- **Purpose**: docker_configuration
- **Settings**: 0

### `docker/base-images/python-deps/Dockerfile`

- **Type**: dockerfile
- **Purpose**: docker_configuration
- **Settings**: 2

### `tests/mind2web_data/processed.json`

- **Type**: json
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `tests/agent_tasks/browser_use_pip.yaml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `tests/agent_tasks/amazon_laptop.yaml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `docs/docs.json`

- **Type**: json
- **Purpose**: ci_cd_configuration
- **Settings**: 26

### `.github/workflows/stale-bot.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/publish.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/lint.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/test.yaml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/cloud_evals.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/claude.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/package.yaml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/eval-on-pr.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/workflows/docker.yml`

- **Type**: yaml
- **Purpose**: docker_configuration
- **Settings**: 0

### `.github/ISSUE_TEMPLATE/1_element_detection_bug.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/ISSUE_TEMPLATE/3_feature_request.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/ISSUE_TEMPLATE/config.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/ISSUE_TEMPLATE/2_bug_report.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `.github/ISSUE_TEMPLATE/4_docs_issue.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `browser_use/config.py`

- **Type**: python
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `browser_use/mcp/manifest.json`

- **Type**: json
- **Purpose**: ci_cd_configuration
- **Settings**: 133

