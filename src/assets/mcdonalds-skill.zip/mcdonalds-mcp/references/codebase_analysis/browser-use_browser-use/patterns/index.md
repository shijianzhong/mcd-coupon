# Design Patterns

*Detected patterns from C3.1 analysis*

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/actor/element.py

### Strategy

- **Class**: `Position`
- **Confidence**: 0.50

### Strategy

- **Class**: `BoundingBox`
- **Confidence**: 0.50

### Strategy

- **Class**: `ElementInfo`
- **Confidence**: 0.50

### Factory

- **Class**: `Element`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/actor/page.py

### Factory

- **Class**: `Page`
- **Confidence**: 0.90

### Decorator

- **Class**: `Page`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/actor/utils.py

### Factory

- **Class**: `Utils`
- **Confidence**: 0.60

### Decorator

- **Class**: `Utils`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/cloud_events.py

### Decorator

- **Class**: `UpdateAgentTaskEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `UpdateAgentTaskEvent`
- **Confidence**: 0.70

### Command

- **Class**: `UpdateAgentTaskEvent`
- **Confidence**: 0.65

### Decorator

- **Class**: `CreateAgentOutputFileEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `CreateAgentOutputFileEvent`
- **Confidence**: 0.70

### Decorator

- **Class**: `CreateAgentStepEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `CreateAgentStepEvent`
- **Confidence**: 0.70

### Decorator

- **Class**: `CreateAgentTaskEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `CreateAgentTaskEvent`
- **Confidence**: 0.70

### Command

- **Class**: `CreateAgentTaskEvent`
- **Confidence**: 0.65

### Decorator

- **Class**: `CreateAgentSessionEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `CreateAgentSessionEvent`
- **Confidence**: 0.70

### Strategy

- **Class**: `UpdateAgentSessionEvent`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/message_manager/service.py

### Factory

- **Class**: `MessageManager`
- **Confidence**: 0.90

### Decorator

- **Class**: `MessageManager`
- **Confidence**: 0.30

### Observer

- **Class**: `MessageManager`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/message_manager/views.py

### Strategy

- **Class**: `HistoryItem`
- **Confidence**: 0.70

### Factory

- **Class**: `MessageHistory`
- **Confidence**: 0.60

### Strategy

- **Class**: `MessageHistory`
- **Confidence**: 0.70

### Strategy

- **Class**: `MessageManagerState`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/prompts.py

### Factory

- **Class**: `SystemPrompt`
- **Confidence**: 0.60

### Factory

- **Class**: `AgentMessagePrompt`
- **Confidence**: 0.90

### Decorator

- **Class**: `AgentMessagePrompt`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/service.py

### Factory

- **Class**: `Agent`
- **Confidence**: 0.90

### Decorator

- **Class**: `Agent`
- **Confidence**: 0.30

### Adapter

- **Class**: `Agent`
- **Confidence**: 0.60

### Observer

- **Class**: `Agent`
- **Confidence**: 0.95

### Command

- **Class**: `Agent`
- **Confidence**: 0.70

### TemplateMethod

- **Class**: `Agent`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/agent/views.py

### Strategy

- **Class**: `AgentSettings`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentState`
- **Confidence**: 0.50

### Strategy

- **Class**: `JudgementResult`
- **Confidence**: 0.50

### Decorator

- **Class**: `ActionResult`
- **Confidence**: 0.30

### Strategy

- **Class**: `ActionResult`
- **Confidence**: 0.70

### Command

- **Class**: `ActionResult`
- **Confidence**: 0.65

### Strategy

- **Class**: `RerunSummaryAction`
- **Confidence**: 0.50

### Command

- **Class**: `RerunSummaryAction`
- **Confidence**: 0.65

### Decorator

- **Class**: `StepMetadata`
- **Confidence**: 0.30

### Strategy

- **Class**: `StepMetadata`
- **Confidence**: 0.70

### Strategy

- **Class**: `AgentBrain`
- **Confidence**: 0.50

### Decorator

- **Class**: `AgentOutput`
- **Confidence**: 0.30

### Adapter

- **Class**: `AgentOutput`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentOutput`
- **Confidence**: 0.90

### Factory

- **Class**: `AgentHistory`
- **Confidence**: 0.60

### Decorator

- **Class**: `AgentHistory`
- **Confidence**: 0.30

### Adapter

- **Class**: `AgentHistory`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentHistory`
- **Confidence**: 0.50

### Factory

- **Class**: `AgentHistoryList`
- **Confidence**: 0.60

### Decorator

- **Class**: `AgentHistoryList`
- **Confidence**: 0.30

### Adapter

- **Class**: `AgentHistoryList`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentHistoryList`
- **Confidence**: 0.50

### Decorator

- **Class**: `AgentError`
- **Confidence**: 0.30

### Strategy

- **Class**: `DetectedVariable`
- **Confidence**: 0.50

### Strategy

- **Class**: `VariableMetadata`
- **Confidence**: 0.50

### Decorator

- **Class**: `AgentOutputNoThinking`
- **Confidence**: 0.30

### Strategy

- **Class**: `AgentOutputNoThinking`
- **Confidence**: 0.70

### Decorator

- **Class**: `AgentOutputFlashMode`
- **Confidence**: 0.30

### Strategy

- **Class**: `AgentOutputFlashMode`
- **Confidence**: 0.70

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/cloud/cloud.py

### Factory

- **Class**: `CloudBrowserClient`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/cloud/views.py

### Strategy

- **Class**: `CreateBrowserRequest`
- **Confidence**: 0.50

### Strategy

- **Class**: `CloudBrowserResponse`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/demo_mode.py

### Factory

- **Class**: `DemoMode`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/events.py

### Decorator

- **Class**: `ElementSelectedEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `BrowserStartEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserStopEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserKillEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserConnectedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserStoppedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `TabCreatedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `TabClosedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentFocusChangedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `TargetCrashedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `NavigationStartedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `NavigationCompleteEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserErrorEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `SaveStorageStateEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `StorageStateSavedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `LoadStorageStateEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `StorageStateLoadedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `FileDownloadedEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `AboutBlankDVDScreensaverShownEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `DialogOpenedEvent`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/profile.py

### Factory

- **Class**: `ViewportSize`
- **Confidence**: 0.60

### Strategy

- **Class**: `ViewportSize`
- **Confidence**: 0.70

### Strategy

- **Class**: `RecordHarContent`
- **Confidence**: 0.50

### Strategy

- **Class**: `RecordHarMode`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserChannel`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserContextArgs`
- **Confidence**: 0.90

### Strategy

- **Class**: `BrowserConnectArgs`
- **Confidence**: 0.50

### Decorator

- **Class**: `BrowserLaunchArgs`
- **Confidence**: 0.30

### Adapter

- **Class**: `BrowserLaunchArgs`
- **Confidence**: 0.50

### Strategy

- **Class**: `BrowserLaunchArgs`
- **Confidence**: 0.90

### Strategy

- **Class**: `BrowserNewContextArgs`
- **Confidence**: 0.50

### Decorator

- **Class**: `BrowserLaunchPersistentContextArgs`
- **Confidence**: 0.30

### Strategy

- **Class**: `BrowserLaunchPersistentContextArgs`
- **Confidence**: 0.70

### Factory

- **Class**: `ProxySettings`
- **Confidence**: 0.60

### Decorator

- **Class**: `ProxySettings`
- **Confidence**: 0.65

### Strategy

- **Class**: `ProxySettings`
- **Confidence**: 0.70

### Factory

- **Class**: `BrowserProfile`
- **Confidence**: 0.90

### Decorator

- **Class**: `BrowserProfile`
- **Confidence**: 0.30

### Adapter

- **Class**: `BrowserProfile`
- **Confidence**: 0.50

### TemplateMethod

- **Class**: `BrowserProfile`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/session.py

### Strategy

- **Class**: `Target`
- **Confidence**: 0.50

### Strategy

- **Class**: `CDPSession`
- **Confidence**: 0.50

### Factory

- **Class**: `BrowserSession`
- **Confidence**: 0.90

### Decorator

- **Class**: `BrowserSession`
- **Confidence**: 0.30

### Adapter

- **Class**: `BrowserSession`
- **Confidence**: 0.50

### Observer

- **Class**: `BrowserSession`
- **Confidence**: 0.95

### Strategy

- **Class**: `BrowserSession`
- **Confidence**: 0.50

### TemplateMethod

- **Class**: `BrowserSession`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/session_manager.py

### Factory

- **Class**: `SessionManager`
- **Confidence**: 0.90

### Observer

- **Class**: `SessionManager`
- **Confidence**: 0.60

### TemplateMethod

- **Class**: `SessionManager`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/views.py

### Factory

- **Class**: `TabInfo`
- **Confidence**: 0.90

### Decorator

- **Class**: `TabInfo`
- **Confidence**: 0.30

### Strategy

- **Class**: `TabInfo`
- **Confidence**: 0.70

### Strategy

- **Class**: `PageInfo`
- **Confidence**: 0.50

### Factory

- **Class**: `BrowserStateHistory`
- **Confidence**: 0.60

### TemplateMethod

- **Class**: `BrowserError`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdog_base.py

### Decorator

- **Class**: `BaseWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `BaseWatchdog`
- **Confidence**: 0.50

### Observer

- **Class**: `BaseWatchdog`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/aboutblank_watchdog.py

### Factory

- **Class**: `AboutBlankWatchdog`
- **Confidence**: 0.90

### Adapter

- **Class**: `AboutBlankWatchdog`
- **Confidence**: 0.50

### Observer

- **Class**: `AboutBlankWatchdog`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/crash_watchdog.py

### Factory

- **Class**: `CrashWatchdog`
- **Confidence**: 0.90

### Decorator

- **Class**: `CrashWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `CrashWatchdog`
- **Confidence**: 0.50

### Observer

- **Class**: `CrashWatchdog`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/default_action_watchdog.py

### Factory

- **Class**: `DefaultActionWatchdog`
- **Confidence**: 0.90

### Decorator

- **Class**: `DefaultActionWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `DefaultActionWatchdog`
- **Confidence**: 0.50

### Command

- **Class**: `DefaultActionWatchdog`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/dom_watchdog.py

### Factory

- **Class**: `DOMWatchdog`
- **Confidence**: 0.90

### Decorator

- **Class**: `DOMWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `DOMWatchdog`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/downloads_watchdog.py

### Factory

- **Class**: `DownloadsWatchdog`
- **Confidence**: 0.90

### Decorator

- **Class**: `DownloadsWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `DownloadsWatchdog`
- **Confidence**: 0.50

### Observer

- **Class**: `DownloadsWatchdog`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/local_browser_watchdog.py

### Factory

- **Class**: `LocalBrowserWatchdog`
- **Confidence**: 0.60

### Decorator

- **Class**: `LocalBrowserWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `LocalBrowserWatchdog`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/popups_watchdog.py

### Factory

- **Class**: `PopupsWatchdog`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/recording_watchdog.py

### Factory

- **Class**: `RecordingWatchdog`
- **Confidence**: 0.60

### Adapter

- **Class**: `RecordingWatchdog`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/screenshot_watchdog.py

### Decorator

- **Class**: `ScreenshotWatchdog`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/security_watchdog.py

### Factory

- **Class**: `SecurityWatchdog`
- **Confidence**: 0.90

### Adapter

- **Class**: `SecurityWatchdog`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/browser/watchdogs/storage_state_watchdog.py

### Factory

- **Class**: `StorageStateWatchdog`
- **Confidence**: 0.60

### Decorator

- **Class**: `StorageStateWatchdog`
- **Confidence**: 0.30

### Adapter

- **Class**: `StorageStateWatchdog`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/cli.py

### Observer

- **Class**: `RichLogHandler`
- **Confidence**: 0.65

### Strategy

- **Class**: `RichLogHandler`
- **Confidence**: 0.70

### ChainOfResponsibility

- **Class**: `RichLogHandler`
- **Confidence**: 0.60

### Builder

- **Class**: `BrowserUseApp`
- **Confidence**: 0.50

### Adapter

- **Class**: `BrowserUseApp`
- **Confidence**: 0.50

### Observer

- **Class**: `BrowserUseApp`
- **Confidence**: 0.95

### TemplateMethod

- **Class**: `BrowserUseApp`
- **Confidence**: 0.50

### Observer

- **Class**: `CDPLogHandler`
- **Confidence**: 0.65

### Strategy

- **Class**: `CDPLogHandler`
- **Confidence**: 0.70

### ChainOfResponsibility

- **Class**: `CDPLogHandler`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/code_use/service.py

### Factory

- **Class**: `CodeAgent`
- **Confidence**: 0.90

### Decorator

- **Class**: `CodeAgent`
- **Confidence**: 0.30

### Observer

- **Class**: `CodeAgent`
- **Confidence**: 0.60

### Command

- **Class**: `CodeAgent`
- **Confidence**: 0.70

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/code_use/views.py

### Strategy

- **Class**: `CellType`
- **Confidence**: 0.50

### Strategy

- **Class**: `ExecutionStatus`
- **Confidence**: 0.50

### Strategy

- **Class**: `CodeCell`
- **Confidence**: 0.50

### Factory

- **Class**: `NotebookSession`
- **Confidence**: 0.90

### Decorator

- **Class**: `NotebookSession`
- **Confidence**: 0.30

### Adapter

- **Class**: `NotebookSession`
- **Confidence**: 0.50

### Strategy

- **Class**: `NotebookSession`
- **Confidence**: 0.50

### Strategy

- **Class**: `NotebookExport`
- **Confidence**: 0.50

### Strategy

- **Class**: `CodeAgentModelOutput`
- **Confidence**: 0.50

### Strategy

- **Class**: `CodeAgentResult`
- **Confidence**: 0.50

### Factory

- **Class**: `CodeAgentState`
- **Confidence**: 0.60

### Strategy

- **Class**: `CodeAgentState`
- **Confidence**: 0.70

### Decorator

- **Class**: `CodeAgentStepMetadata`
- **Confidence**: 0.30

### Strategy

- **Class**: `CodeAgentStepMetadata`
- **Confidence**: 0.70

### Strategy

- **Class**: `CodeAgentHistory`
- **Confidence**: 0.70

### Decorator

- **Class**: `CodeAgentHistoryList`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/config.py

### Decorator

- **Class**: `OldConfig`
- **Confidence**: 0.30

### Strategy

- **Class**: `DBStyleEntry`
- **Confidence**: 0.90

### Strategy

- **Class**: `BrowserProfileEntry`
- **Confidence**: 0.50

### Strategy

- **Class**: `LLMEntry`
- **Confidence**: 0.50

### Strategy

- **Class**: `AgentEntry`
- **Confidence**: 0.50

### Strategy

- **Class**: `DBStyleConfigJSON`
- **Confidence**: 0.50

### Factory

- **Class**: `Config`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/serializer/clickable_elements.py

### Decorator

- **Class**: `ClickableElementDetector`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/serializer/code_use_serializer.py

### Factory

- **Class**: `DOMCodeAgentSerializer`
- **Confidence**: 0.80

### Decorator

- **Class**: `DOMCodeAgentSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/serializer/eval_serializer.py

### Factory

- **Class**: `DOMEvalSerializer`
- **Confidence**: 0.80

### Decorator

- **Class**: `DOMEvalSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/serializer/serializer.py

### Factory

- **Class**: `DOMTreeSerializer`
- **Confidence**: 0.90

### Decorator

- **Class**: `DOMTreeSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/service.py

### Factory

- **Class**: `DomService`
- **Confidence**: 0.90

### Decorator

- **Class**: `DomService`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/dom/views.py

### Strategy

- **Class**: `MatchLevel`
- **Confidence**: 0.50

### Factory

- **Class**: `EnhancedDOMTreeNode`
- **Confidence**: 0.90

### Decorator

- **Class**: `EnhancedDOMTreeNode`
- **Confidence**: 0.30

### Decorator

- **Class**: `SerializedDOMState`
- **Confidence**: 0.30

### Decorator

- **Class**: `DOMInteractedElement`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/filesystem/file_system.py

### Factory

- **Class**: `BaseFile`
- **Confidence**: 0.90

### Decorator

- **Class**: `BaseFile`
- **Confidence**: 0.30

### Adapter

- **Class**: `BaseFile`
- **Confidence**: 0.50

### Observer

- **Class**: `BaseFile`
- **Confidence**: 0.65

### Strategy

- **Class**: `BaseFile`
- **Confidence**: 0.90

### TemplateMethod

- **Class**: `BaseFile`
- **Confidence**: 0.60

### Decorator

- **Class**: `MarkdownFile`
- **Confidence**: 0.30

### Strategy

- **Class**: `MarkdownFile`
- **Confidence**: 0.70

### Decorator

- **Class**: `TxtFile`
- **Confidence**: 0.30

### Strategy

- **Class**: `TxtFile`
- **Confidence**: 0.70

### Decorator

- **Class**: `JsonFile`
- **Confidence**: 0.30

### Strategy

- **Class**: `JsonFile`
- **Confidence**: 0.70

### Decorator

- **Class**: `CsvFile`
- **Confidence**: 0.30

### Strategy

- **Class**: `CsvFile`
- **Confidence**: 0.70

### Decorator

- **Class**: `JsonlFile`
- **Confidence**: 0.30

### Strategy

- **Class**: `JsonlFile`
- **Confidence**: 0.70

### Decorator

- **Class**: `PdfFile`
- **Confidence**: 0.30

### Adapter

- **Class**: `PdfFile`
- **Confidence**: 0.50

### Strategy

- **Class**: `PdfFile`
- **Confidence**: 0.50

### Decorator

- **Class**: `DocxFile`
- **Confidence**: 0.30

### Adapter

- **Class**: `DocxFile`
- **Confidence**: 0.50

### Strategy

- **Class**: `DocxFile`
- **Confidence**: 0.50

### Strategy

- **Class**: `FileSystemState`
- **Confidence**: 0.50

### Factory

- **Class**: `FileSystem`
- **Confidence**: 0.90

### Decorator

- **Class**: `FileSystem`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/integrations/gmail/service.py

### Factory

- **Class**: `GmailService`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/anthropic/chat.py

### Factory

- **Class**: `ChatAnthropic`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatAnthropic`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatAnthropic`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/anthropic/serializer.py

### Decorator

- **Class**: `AnthropicMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/aws/chat_anthropic.py

### Factory

- **Class**: `ChatAnthropicBedrock`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatAnthropicBedrock`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatAnthropicBedrock`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/aws/chat_bedrock.py

### Factory

- **Class**: `ChatAWSBedrock`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatAWSBedrock`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatAWSBedrock`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/aws/serializer.py

### Decorator

- **Class**: `AWSBedrockMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/azure/chat.py

### Factory

- **Class**: `ChatAzureOpenAI`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatAzureOpenAI`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatAzureOpenAI`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/base.py

### Factory

- **Class**: `BaseChatModel`
- **Confidence**: 0.65

### Decorator

- **Class**: `BaseChatModel`
- **Confidence**: 0.30

### Adapter

- **Class**: `BaseChatModel`
- **Confidence**: 0.55

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/browser_use/chat.py

### Factory

- **Class**: `ChatBrowserUse`
- **Confidence**: 0.60

### Decorator

- **Class**: `ChatBrowserUse`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatBrowserUse`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/cerebras/chat.py

### Factory

- **Class**: `ChatCerebras`
- **Confidence**: 0.60

### Decorator

- **Class**: `ChatCerebras`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatCerebras`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/cerebras/serializer.py

### Decorator

- **Class**: `CerebrasMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/deepseek/chat.py

### Decorator

- **Class**: `ChatDeepSeek`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatDeepSeek`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/deepseek/serializer.py

### Decorator

- **Class**: `DeepSeekMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/exceptions.py

### TemplateMethod

- **Class**: `ModelProviderError`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/google/chat.py

### Factory

- **Class**: `ChatGoogle`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatGoogle`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatGoogle`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/google/serializer.py

### Decorator

- **Class**: `GoogleMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/groq/chat.py

### Factory

- **Class**: `ChatGroq`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatGroq`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatGroq`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/groq/serializer.py

### Decorator

- **Class**: `GroqMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/messages.py

### Strategy

- **Class**: `ContentPartTextParam`
- **Confidence**: 0.70

### Strategy

- **Class**: `ContentPartRefusalParam`
- **Confidence**: 0.70

### Strategy

- **Class**: `ImageURL`
- **Confidence**: 0.70

### Strategy

- **Class**: `ContentPartImageParam`
- **Confidence**: 0.70

### Strategy

- **Class**: `Function`
- **Confidence**: 0.70

### Strategy

- **Class**: `ToolCall`
- **Confidence**: 0.70

### Strategy

- **Class**: `_MessageBase`
- **Confidence**: 0.90

### TemplateMethod

- **Class**: `_MessageBase`
- **Confidence**: 0.60

### Decorator

- **Class**: `UserMessage`
- **Confidence**: 0.30

### Adapter

- **Class**: `UserMessage`
- **Confidence**: 0.50

### Strategy

- **Class**: `UserMessage`
- **Confidence**: 0.50

### Decorator

- **Class**: `SystemMessage`
- **Confidence**: 0.30

### Adapter

- **Class**: `SystemMessage`
- **Confidence**: 0.50

### Strategy

- **Class**: `SystemMessage`
- **Confidence**: 0.50

### Decorator

- **Class**: `AssistantMessage`
- **Confidence**: 0.30

### Adapter

- **Class**: `AssistantMessage`
- **Confidence**: 0.50

### Strategy

- **Class**: `AssistantMessage`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/mistral/chat.py

### Factory

- **Class**: `ChatMistral`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatMistral`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatMistral`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/mistral/schema.py

### Factory

- **Class**: `MistralSchemaOptimizer`
- **Confidence**: 0.50

### Decorator

- **Class**: `MistralSchemaOptimizer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/oci_raw/chat.py

### Factory

- **Class**: `ChatOCIRaw`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatOCIRaw`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatOCIRaw`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/oci_raw/serializer.py

### Factory

- **Class**: `OCIRawMessageSerializer`
- **Confidence**: 0.60

### Decorator

- **Class**: `OCIRawMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/ollama/chat.py

### Factory

- **Class**: `ChatOllama`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatOllama`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatOllama`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/ollama/serializer.py

### Decorator

- **Class**: `OllamaMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/openai/chat.py

### Factory

- **Class**: `ChatOpenAI`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatOpenAI`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatOpenAI`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/openai/responses_serializer.py

### Decorator

- **Class**: `ResponsesAPIMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/openai/serializer.py

### Decorator

- **Class**: `OpenAIMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/openrouter/chat.py

### Factory

- **Class**: `ChatOpenRouter`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatOpenRouter`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatOpenRouter`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/openrouter/serializer.py

### Decorator

- **Class**: `OpenRouterMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/schema.py

### Factory

- **Class**: `SchemaOptimizer`
- **Confidence**: 0.90

### Decorator

- **Class**: `SchemaOptimizer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/tests/test_chat_models.py

### Decorator

- **Class**: `TestChatModels`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/tests/test_mistral_schema.py

### Strategy

- **Class**: `NestedExample`
- **Confidence**: 0.50

### Strategy

- **Class**: `RootExample`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/vercel/chat.py

### Factory

- **Class**: `ChatVercel`
- **Confidence**: 0.90

### Decorator

- **Class**: `ChatVercel`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatVercel`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/vercel/serializer.py

### Decorator

- **Class**: `VercelMessageSerializer`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/llm/views.py

### Strategy

- **Class**: `ChatInvokeUsage`
- **Confidence**: 0.50

### Strategy

- **Class**: `ChatInvokeCompletion`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/logging_config.py

### Adapter

- **Class**: `FIFOHandler`
- **Confidence**: 0.50

### Observer

- **Class**: `FIFOHandler`
- **Confidence**: 0.65

### ChainOfResponsibility

- **Class**: `FIFOHandler`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/mcp/client.py

### Observer

- **Class**: `MCPClient`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/mcp/controller.py

### Decorator

- **Class**: `MCPToolWrapper`
- **Confidence**: 0.65

### Adapter

- **Class**: `MCPToolWrapper`
- **Confidence**: 0.70

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/mcp/server.py

### Factory

- **Class**: `BrowserUseServer`
- **Confidence**: 0.50

### Observer

- **Class**: `BrowserUseServer`
- **Confidence**: 0.65

### Command

- **Class**: `BrowserUseServer`
- **Confidence**: 0.70

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/sandbox/views.py

### Strategy

- **Class**: `BrowserCreatedData`
- **Confidence**: 0.50

### Strategy

- **Class**: `LogData`
- **Confidence**: 0.50

### Strategy

- **Class**: `ExecutionResponse`
- **Confidence**: 0.50

### Strategy

- **Class**: `ResultData`
- **Confidence**: 0.50

### Strategy

- **Class**: `ErrorData`
- **Confidence**: 0.50

### Factory

- **Class**: `SSEEvent`
- **Confidence**: 0.60

### Decorator

- **Class**: `SSEEvent`
- **Confidence**: 0.30

### Adapter

- **Class**: `SSEEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `SSEEvent`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/screenshots/service.py

### Factory

- **Class**: `ScreenshotService`
- **Confidence**: 0.50

### Decorator

- **Class**: `ScreenshotService`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/skills/service.py

### Factory

- **Class**: `SkillService`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/skills/views.py

### Decorator

- **Class**: `Skill`
- **Confidence**: 0.30

### Adapter

- **Class**: `Skill`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/sync/auth.py

### Decorator

- **Class**: `CloudAuthConfig`
- **Confidence**: 0.30

### Factory

- **Class**: `DeviceAuthClient`
- **Confidence**: 0.60

### Decorator

- **Class**: `DeviceAuthClient`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/telemetry/service.py

### Decorator

- **Class**: `ProductTelemetry`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/telemetry/views.py

### Decorator

- **Class**: `BaseTelemetryEvent`
- **Confidence**: 0.30

### Strategy

- **Class**: `BaseTelemetryEvent`
- **Confidence**: 0.80

### TemplateMethod

- **Class**: `BaseTelemetryEvent`
- **Confidence**: 0.60

### Strategy

- **Class**: `AgentTelemetryEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `MCPClientTelemetryEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `MCPServerTelemetryEvent`
- **Confidence**: 0.50

### Strategy

- **Class**: `CLITelemetryEvent`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tokens/service.py

### Factory

- **Class**: `TokenCost`
- **Confidence**: 0.90

### Observer

- **Class**: `TokenCost`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tokens/views.py

### Strategy

- **Class**: `TokenUsageEntry`
- **Confidence**: 0.50

### Decorator

- **Class**: `TokenCostCalculated`
- **Confidence**: 0.30

### Strategy

- **Class**: `TokenCostCalculated`
- **Confidence**: 0.70

### Strategy

- **Class**: `ModelPricing`
- **Confidence**: 0.50

### Strategy

- **Class**: `CachedPricingData`
- **Confidence**: 0.50

### Strategy

- **Class**: `ModelUsageStats`
- **Confidence**: 0.50

### Strategy

- **Class**: `ModelUsageTokens`
- **Confidence**: 0.50

### Strategy

- **Class**: `UsageSummary`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tools/registry/service.py

### Factory

- **Class**: `Registry`
- **Confidence**: 0.90

### Decorator

- **Class**: `Registry`
- **Confidence**: 0.30

### Factory

- **Class**: `ActionModelUnion`
- **Confidence**: 0.60

### Command

- **Class**: `ActionModelUnion`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tools/registry/views.py

### Strategy

- **Class**: `RegisteredAction`
- **Confidence**: 0.70

### Command

- **Class**: `RegisteredAction`
- **Confidence**: 0.65

### Factory

- **Class**: `ActionModel`
- **Confidence**: 0.60

### Strategy

- **Class**: `ActionModel`
- **Confidence**: 0.70

### Command

- **Class**: `ActionModel`
- **Confidence**: 0.65

### Factory

- **Class**: `ActionRegistry`
- **Confidence**: 0.60

### Decorator

- **Class**: `ActionRegistry`
- **Confidence**: 0.30

### Strategy

- **Class**: `ActionRegistry`
- **Confidence**: 0.70

### Command

- **Class**: `ActionRegistry`
- **Confidence**: 0.65

### Factory

- **Class**: `SpecialActionParameters`
- **Confidence**: 0.60

### Decorator

- **Class**: `SpecialActionParameters`
- **Confidence**: 0.30

### Strategy

- **Class**: `SpecialActionParameters`
- **Confidence**: 0.70

### Command

- **Class**: `SpecialActionParameters`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tools/service.py

### Factory

- **Class**: `Tools`
- **Confidence**: 0.90

### Decorator

- **Class**: `Tools`
- **Confidence**: 0.30

### Observer

- **Class**: `Tools`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/tools/views.py

### Strategy

- **Class**: `ExtractAction`
- **Confidence**: 0.50

### Command

- **Class**: `ExtractAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `SearchAction`
- **Confidence**: 0.50

### Command

- **Class**: `SearchAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `NavigateAction`
- **Confidence**: 0.50

### Command

- **Class**: `NavigateAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `ClickElementAction`
- **Confidence**: 0.50

### Command

- **Class**: `ClickElementAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `ClickElementActionIndexOnly`
- **Confidence**: 0.50

### Command

- **Class**: `ClickElementActionIndexOnly`
- **Confidence**: 0.65

### Strategy

- **Class**: `InputTextAction`
- **Confidence**: 0.50

### Command

- **Class**: `InputTextAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `DoneAction`
- **Confidence**: 0.50

### Command

- **Class**: `DoneAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `StructuredOutputAction`
- **Confidence**: 0.50

### Command

- **Class**: `StructuredOutputAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `SwitchTabAction`
- **Confidence**: 0.50

### Command

- **Class**: `SwitchTabAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `CloseTabAction`
- **Confidence**: 0.50

### Command

- **Class**: `CloseTabAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `ScrollAction`
- **Confidence**: 0.50

### Command

- **Class**: `ScrollAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `SendKeysAction`
- **Confidence**: 0.50

### Command

- **Class**: `SendKeysAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `UploadFileAction`
- **Confidence**: 0.50

### Command

- **Class**: `UploadFileAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `NoParamsAction`
- **Confidence**: 0.50

### Command

- **Class**: `NoParamsAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `GetDropdownOptionsAction`
- **Confidence**: 0.50

### Command

- **Class**: `GetDropdownOptionsAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `SelectDropdownOptionAction`
- **Confidence**: 0.50

### Command

- **Class**: `SelectDropdownOptionAction`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/browser_use/utils.py

### Observer

- **Class**: `SignalHandler`
- **Confidence**: 0.90

### ChainOfResponsibility

- **Class**: `SignalHandler`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/apps/ad-use/ad_generator.py

### Factory

- **Class**: `AdGenerator`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/browser/playwright_integration.py

### Strategy

- **Class**: `PlaywrightFillFormAction`
- **Confidence**: 0.50

### Command

- **Class**: `PlaywrightFillFormAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `PlaywrightScreenshotAction`
- **Confidence**: 0.50

### Command

- **Class**: `PlaywrightScreenshotAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `PlaywrightGetTextAction`
- **Confidence**: 0.50

### Command

- **Class**: `PlaywrightGetTextAction`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/cloud/03_structured_output.py

### Strategy

- **Class**: `NewsArticle`
- **Confidence**: 0.50

### Strategy

- **Class**: `NewsResponse`
- **Confidence**: 0.50

### Strategy

- **Class**: `ProductInfo`
- **Confidence**: 0.50

### Strategy

- **Class**: `CompanyInfo`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/custom-functions/advanced_search.py

### Strategy

- **Class**: `Person`
- **Confidence**: 0.50

### Strategy

- **Class**: `PersonList`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/custom-functions/cua.py

### Command

- **Class**: `OpenAICUAAction`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/custom-functions/save_to_file_hugging_face.py

### Strategy

- **Class**: `Model`
- **Confidence**: 0.50

### Strategy

- **Class**: `Models`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/features/custom_output.py

### Strategy

- **Class**: `Post`
- **Confidence**: 0.50

### Strategy

- **Class**: `Posts`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/integrations/agentmail/email_tools.py

### Factory

- **Class**: `EmailTools`
- **Confidence**: 0.90

### Adapter

- **Class**: `EmailTools`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/integrations/discord/discord_api.py

### Adapter

- **Class**: `DiscordBot`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/integrations/gmail_2fa_integration.py

### TemplateMethod

- **Class**: `GmailGrantManager`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/models/langchain/chat.py

### Factory

- **Class**: `ChatLangchain`
- **Confidence**: 0.60

### Decorator

- **Class**: `ChatLangchain`
- **Confidence**: 0.30

### Adapter

- **Class**: `ChatLangchain`
- **Confidence**: 0.50

### ChainOfResponsibility

- **Class**: `ChatLangchain`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/models/langchain/serializer.py

### Decorator

- **Class**: `LangChainMessageSerializer`
- **Confidence**: 0.30

### ChainOfResponsibility

- **Class**: `LangChainMessageSerializer`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/ui/gradio_demo.py

### Command

- **Class**: `ActionResult`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/use-cases/buy_groceries.py

### Strategy

- **Class**: `GroceryItem`
- **Confidence**: 0.50

### Strategy

- **Class**: `GroceryCart`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/use-cases/find_influencer_profiles.py

### Strategy

- **Class**: `Profile`
- **Confidence**: 0.50

### Strategy

- **Class**: `Profiles`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/examples/use-cases/phone_comparison.py

### Strategy

- **Class**: `ProductListing`
- **Confidence**: 0.50

### Strategy

- **Class**: `PriceComparison`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/browser/test_cloud_browser.py

### Factory

- **Class**: `TestCloudBrowserClient`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/browser/test_output_paths.py

### Decorator

- **Class**: `TestAgentRecordings`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/browser/test_session_start.py

### Decorator

- **Class**: `TestBrowserSessionStart`
- **Confidence**: 0.30

### Decorator

- **Class**: `TestBrowserSessionEventSystem`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/browser/test_tabs.py

### Factory

- **Class**: `TestMultiTabOperations`
- **Confidence**: 0.50

### Command

- **Class**: `TestMultiTabOperations`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/conftest.py

### Factory

- **Class**: `EventCollector`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/infrastructure/test_filesystem.py

### Factory

- **Class**: `TestFileSystem`
- **Confidence**: 0.90

### Decorator

- **Class**: `TestFileSystem`
- **Confidence**: 0.30

### Factory

- **Class**: `TestFileSystemEdgeCases`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/infrastructure/test_registry_action_parameter_injection.py

### Factory

- **Class**: `TestBrowserContext`
- **Confidence**: 0.90

### Decorator

- **Class**: `TestBrowserContext`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/infrastructure/test_registry_core.py

### Strategy

- **Class**: `SimpleParams`
- **Confidence**: 0.50

### Strategy

- **Class**: `ComplexParams`
- **Confidence**: 0.50

### Command

- **Class**: `TestActionRegistryParameterPatterns`
- **Confidence**: 0.65

### Command

- **Class**: `TestActionToActionCalling`
- **Confidence**: 0.65

### Command

- **Class**: `TestExistingToolsActions`
- **Confidence**: 0.65

### Strategy

- **Class**: `TestParams`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/infrastructure/test_registry_validation.py

### Strategy

- **Class**: `ClickAction`
- **Confidence**: 0.50

### Command

- **Class**: `ClickAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `ExtractAction`
- **Confidence**: 0.50

### Command

- **Class**: `ExtractAction`
- **Confidence**: 0.65

### Strategy

- **Class**: `CellActionParams`
- **Confidence**: 0.50

### Command

- **Class**: `CellActionParams`
- **Confidence**: 0.65

### Strategy

- **Class**: `ModelWithBrowser`
- **Confidence**: 0.50

### Strategy

- **Class**: `CellRangeParams`
- **Confidence**: 0.50

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/interactions/test_dropdown_aria_menus.py

### Factory

- **Class**: `TestARIAMenuDropdown`
- **Confidence**: 0.90

### Decorator

- **Class**: `TestARIAMenuDropdown`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/interactions/test_dropdown_native.py

### Decorator

- **Class**: `TestGetDropdownOptionsEvent`
- **Confidence**: 0.30

### Decorator

- **Class**: `TestSelectDropdownOptionEvent`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/models/test_azure_responses_api.py

### Decorator

- **Class**: `TestChatAzureOpenAIIntegration`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/security/test_domain_filtering.py

### Observer

- **Class**: `TestUrlAllowlistSecurity`
- **Confidence**: 0.95

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_coordinate_clicking.py

### Decorator

- **Class**: `TestCoordinateClickingModelDetection`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_extension_config.py

### Decorator

- **Class**: `TestDisableExtensionsEnvVar`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_fallback_llm.py

### Factory

- **Class**: `TestFallbackLLMIntegration`
- **Confidence**: 0.90

### Decorator

- **Class**: `TestFallbackLLMIntegration`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_file_system_docx.py

### Factory

- **Class**: `TestDocxFile`
- **Confidence**: 0.50

### Decorator

- **Class**: `TestDocxFile`
- **Confidence**: 0.30

### Observer

- **Class**: `TestDocxFile`
- **Confidence**: 0.60

### Decorator

- **Class**: `TestFileSystemDocxIntegration`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_file_system_images.py

### Factory

- **Class**: `TestImageFiles`
- **Confidence**: 0.50

### Decorator

- **Class**: `TestImageFiles`
- **Confidence**: 0.30

### Command

- **Class**: `TestActionResultImages`
- **Confidence**: 0.65

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_file_system_llm_integration.py

### Factory

- **Class**: `TestImageInLLMMessages`
- **Confidence**: 0.50

### Decorator

- **Class**: `TestImageInLLMMessages`
- **Confidence**: 0.30

### Decorator

- **Class**: `TestDocxInLLMMessages`
- **Confidence**: 0.30

### Factory

- **Class**: `TestEndToEndIntegration`
- **Confidence**: 0.60

### Decorator

- **Class**: `TestEndToEndIntegration`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_llm_retries.py

### Decorator

- **Class**: `TestChatBrowserUseRetries`
- **Confidence**: 0.30

### Decorator

- **Class**: `TestChatGoogleRetries`
- **Confidence**: 0.30

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_markdown_extractor.py

### Observer

- **Class**: `TestPreprocessMarkdownContent`
- **Confidence**: 0.60

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_sandbox_structured_output.py

### Strategy

- **Class**: `ExtractedData`
- **Confidence**: 0.50

### Strategy

- **Class**: `NestedModel`
- **Confidence**: 0.50

### Factory

- **Class**: `TestGetStructuredOutput`
- **Confidence**: 0.90

## /Users/shijianzhong/sking/Skill_Seekers/.skillseeker-cache/mcdonalds-mcp/repos/0_browser-use_browser-use/tests/ci/test_tools.py

### Factory

- **Class**: `TestToolsIntegration`
- **Confidence**: 0.50

