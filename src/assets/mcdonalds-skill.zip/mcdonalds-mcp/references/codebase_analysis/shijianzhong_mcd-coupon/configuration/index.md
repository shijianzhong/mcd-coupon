# Configuration Patterns

*Detected configuration files (C3.4)*

**Total Config Files**: 4

## Configuration Files

### `Cargo.toml`

- **Type**: toml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

### `mcd-coupon-config.example.json`

- **Type**: json
- **Purpose**: ci_cd_configuration
- **Settings**: 1

### `mcp.json`

- **Type**: json
- **Purpose**: ci_cd_configuration
- **Settings**: 5

### `.github/workflows/release.yml`

- **Type**: yaml
- **Purpose**: ci_cd_configuration
- **Settings**: 0

