# GitHub: browser-use/browser-use

**Stars**: 75714
**Language**: Python
**Issues**: 0
**Releases**: 0

## Files

- [README.md](README.md)
