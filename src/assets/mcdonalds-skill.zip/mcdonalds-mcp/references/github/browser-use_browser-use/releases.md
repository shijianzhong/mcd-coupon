# Releases: browser-use/browser-use

## 0.11.3: 0.11.3

**Published**: 2026-01-16

## What's Changed
* Bu_oss example flash mode by @mertunsall in https://github.com/browser-use/browser-use/pull/3774
* include ax_name for rerun history element hash by @sauravpanda in https://github.com/browser-use/browser-use/pull/3775
* Dont skip failrues by default by @mertunsall in https://github.com/browser-use/browser-use/pull/3777
* fix: Cascading element matching for history rerun stability by @mertunsall in https://github.com/browser-use/browser-use/pull/3781
* feat: added Unique 

## 0.11.2: BROWSER USE OSS MODEL!!!

**Published**: 2025-12-16

We released an open source model specialized in Browser Use https://huggingface.co/browser-use/bu-30b-a3b-preview.

Check it out 🚀 

## What's Changed
* perf: lazy import for openai and reportlab to reduce startup latency by @hacking-racoon in https://github.com/browser-use/browser-use/pull/3764
* Fix XAI vision check to only disable for grok-3 and grok-code models by @bbarwik in https://github.com/browser-use/browser-use/pull/3762
* max wait between execution by @mertunsall in https://gi

## 0.11.1: More Stable

**Published**: 2025-12-12

## What's Changed
* docs: fix default action count in docs by @sauravpanda in https://github.com/browser-use/browser-use/pull/3741
* update system prompts by @mertunsall in https://github.com/browser-use/browser-use/pull/3746
* docs fix ChatOpenAI import path by @sauravpanda in https://github.com/browser-use/browser-use/pull/3748
* Fix short line removal bug by @mertunsall in https://github.com/browser-use/browser-use/pull/3749
* Filter sensitive data in history by @mertunsall in https://gi

## 0.11.0: 0.11.0 - Skills

**Published**: 2025-12-10

```python
from browser_use import Agent, ChatBrowserUse

agent = Agent(
    task='Your task',
    skills=['skill-uuid-1', 'skill-uuid-2'],  # Specific skills (recommended)
    # or
    # skills=['*'],  # All skills
    llm=ChatBrowserUse()
)

await agent.run()
```

## What's Changed
* Add cloud by @mertunsall in https://github.com/browser-use/browser-use/pull/3692
* Add Mistral chat provider with schema sanitization and presets by @MagellaX in https://github.com/browser-use/brows

## 0.10.1: 0.10.1

**Published**: 2025-11-29

Release again because forgot to bump pyproject :)

## What's Changed
* Bump pyproject to 0.10.0 by @mertunsall in https://github.com/browser-use/browser-use/pull/3690
* Bump dependency to 0.10.1 by @mertunsall in https://github.com/browser-use/browser-use/pull/3691


**Full Changelog**: https://github.com/browser-use/browser-use/compare/0.10.0...0.10.1

## 0.10.0: Browser Use with Community!

**Published**: 2025-11-29

In this release, we merged many PRs from the community into Browser Use and made the library significantly more stable!

## What's Changed
* more timeout for gemini 3 pro by @mertunsall in https://github.com/browser-use/browser-use/pull/3618
* Record click coordinates in agent's system by @mertunsall in https://github.com/browser-use/browser-use/pull/3621
* fix: Add default=True to ScrollAction.down field to handle LLM respon… by @Utkarshkarki in https://github.com/browser-use/browser-use/p

## 0.9.7: 0.9.7 - Gemini 3 available

**Published**: 2025-11-18

## What's Changed
* Fix: Ignore Inert Carousel Elements by @PredictiveManish in https://github.com/browser-use/browser-use/pull/3564
* Revert "Fix: Ignore Inert Carousel Elements" by @mertunsall in https://github.com/browser-use/browser-use/pull/3598
* Configure screenshot size for browser-use models by @mertunsall in https://github.com/browser-use/browser-use/pull/3603
* fix max steps bug by @mertunsall in https://github.com/browser-use/browser-use/pull/3607
* Updated Laminar docs by @skul

## 0.9.6: 0.9.6 - Automatic llm as a judge for your agent runs to monitor success 

**Published**: 2025-11-15

## What's Changed
* change example by @MagMueller in https://github.com/browser-use/browser-use/pull/3494
* fix: improved sandbox example removing bugged output_model_schema by @reformedot in https://github.com/browser-use/browser-use/pull/3495
* Updated openai logging by @krishnarathore12 in https://github.com/browser-use/browser-use/pull/3503
* Updated faq section in the readme by @krishnarathore12 in https://github.com/browser-use/browser-use/pull/3502
* Update file write tool and log lo

## 0.9.5: 0.9.5 - Sandboxes

**Published**: 2025-11-01

## What's Changed
* small-fixes2 by @MagMueller in https://github.com/browser-use/browser-use/pull/3457
* fix link to supported models documentation by @Timoite in https://github.com/browser-use/browser-use/pull/3460
* download-less by @MagMueller in https://github.com/browser-use/browser-use/pull/3462
* remove-popups by @MagMueller in https://github.com/browser-use/browser-use/pull/3464
* docs: added pricing for bu llm by @sauravpanda in https://github.com/browser-use/browser-use/pull/3465

## 0.9.4: 0.9.4

**Published**: 2025-10-29

## What's Changed
* make pip workflow funciton by installing uv from pip by @Alezander9 in https://github.com/browser-use/browser-use/pull/3454
* remove ads inserted by other companies by @Alezander9 in https://github.com/browser-use/browser-use/pull/3455
* feat: improved session manager by @reformedot in https://github.com/browser-use/browser-use/pull/3430


**Full Changelog**: https://github.com/browser-use/browser-use/compare/0.9.3...0.9.4

