# GitHub References

Combined from 2 GitHub repositories.

## Repositories

- [browser-use/browser-use](browser-use_browser-use/index.md) - 75714 stars
- [shijianzhong/mcd-coupon](shijianzhong_mcd-coupon/index.md) - 0 stars
