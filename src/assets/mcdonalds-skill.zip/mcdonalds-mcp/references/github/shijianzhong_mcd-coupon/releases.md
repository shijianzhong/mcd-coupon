# Releases: shijianzhong/mcd-coupon

## v0.3.0: v0.3.0

**Published**: 2026-01-19

**Full Changelog**: https://github.com/shijianzhong/mcd-coupon/compare/v0.2.0...v0.3.0

## v0.2.0: v0.2.0

**Published**: 2026-01-19

**Full Changelog**: https://github.com/shijianzhong/mcd-coupon/compare/v0.1.0...v0.2.0

## v0.1.0: v0.1.0

**Published**: 2026-01-19

**Full Changelog**: https://github.com/shijianzhong/mcd-coupon/commits/v0.1.0

